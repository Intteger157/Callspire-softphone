<?php
/**
 * ACL helpers for ModuleUsersUI: stock AmoCRM admin controller FQCN → this fork’s FQCN.
 */
namespace Modules\ModuleAmoCrmCustom\Lib;

use Modules\ModuleAmoCrmCustom\App\Controllers\ModuleAmoCrmController;

class ModuleAmoCrmCustomACL
{
    /** Official module admin controller (stored in AccessGroupsRights when rights were granted). */
    private const LEGACY_CONTROLLER = 'Modules\ModuleAmoCrm\App\Controllers\ModuleAmoCrmController';

    /**
     * @return array<string, array<string, array<string, array<int, string>>>>
     */
    public static function getLinkedControllerActions(): array
    {
        $fork = ModuleAmoCrmController::class;
        $grantOnFork = ['*'];
        $legacyActions = [
            'index',
            'save',
            'modify',
            'saveEntitySettings',
            'delete',
            'saveTableData',
            'changePriority',
            'check',
            'getTablesDescription',
            'getNewRecords',
            'save-entity-settings',
            'save-table-data',
            'change-priority',
            'get-tables-description',
            'get-new-records',
        ];
        $byLegacyAction = [];
        foreach ($legacyActions as $action) {
            $byLegacyAction[$action] = [$fork => $grantOnFork];
        }

        return [self::LEGACY_CONTROLLER => $byLegacyAction];
    }
}
