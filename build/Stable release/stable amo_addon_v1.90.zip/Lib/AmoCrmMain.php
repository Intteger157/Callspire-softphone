<?php

namespace Modules\ModuleAmoCrm\Lib;

use GuzzleHttp\Client;
use MikoPBX\Core\System\Util;
use MikoPBX\Modules\PbxExtensionUtils;
use MikoPBX\PBXCoreREST\Lib\PBXApiResult;
use Modules\ModuleAmoCrm\bin\ConnectorDb;
use MikoPBX\Common\Models\Extensions;
use MikoPBX\Common\Models\PbxSettings;
use JsonException;

/**
 * Объект класса существует только как свойство объекта WorkerAmoHTTP.
 */
class AmoCrmMain extends AmoCrmMainBase
{
    private string $baseDomain = '';
    private AuthToken $token;
    private bool $initDone = false;

    public bool   $isPrivateWidget;
    public string $privateClientId;
    public string $privateClientSecret;

    /** OAuth amo для загрузки записей в Drive (отдельная интеграция в маркетплейсе). */
    private string $driveClientId = '';
    private string $driveClientSecret = '';
    private string $driveRedirectUri = '';
    private ?AuthToken $driveToken = null;

    private ?string $cachedDriveUrl = null;

    public const ENTITY_CONTACTS = 'contacts';
    public const ENTITY_COMPANIES = 'companies';
    public const ENTITY_LEADS = 'leads';

    public const EMPTY_HOST_VALUE = 'EMPTY_HOST_VALUE';

    /**
     * Инициализации API клиента.
     * AmoCrmMain constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $allSettings = ConnectorDb::invoke('getModuleSettings', [true]);
        if(!empty($allSettings) && is_array($allSettings)){
            $settings = (object)$allSettings['ModuleAmoCrm'];
        }else{
            exit(3);
        }

        if($settings){
            $this->baseDomain           = ''.$settings->baseDomain;
            $this->token               = new AuthToken((string)$settings->authData);
            $this->isPrivateWidget     = (string)$settings->isPrivateWidget === '1';
            $this->privateClientId     = ''.$settings->privateClientId;
            $this->privateClientSecret = ''.$settings->privateClientSecret;
            $this->driveClientId       = trim((string)($settings->driveClientId ?? ''));
            $this->driveClientSecret   = trim((string)($settings->driveClientSecret ?? ''));
            $this->driveRedirectUri    = trim((string)($settings->driveRedirectUri ?? ''));
            $driveAuthTrim             = trim((string)($settings->driveAuthData ?? ''));
            if ($driveAuthTrim !== '') {
                $this->driveToken = new AuthToken($driveAuthTrim);
            }
            $this->refreshToken();
            if ($this->driveToken !== null) {
                $this->refreshDriveToken();
            }
            $this->initDone = true;
        }
        if(empty($this->baseDomain)){
            exit(4);
        }
    }

    /**
     * Инициализирован ли объект?
     * @return bool
     */
    public function isInitDone():bool
    {
        return $this->initDone;
    }

    /**
     * Return client ID.
     * @return string
     */
    private function getClientId():string
    {
        if($this->isPrivateWidget) {
            return $this->privateClientId;
        }
        return self::CLIENT_ID;
    }

    /**
     * Return client secret
     * @return string
     */
    private function getClientSecret():string
    {
        if($this->isPrivateWidget){
            return $this->privateClientSecret;
        }
        return self::CLIENT_SECRET;
    }

    /**
     * Redirect URI для OAuth интеграции Drive (должен совпадать с настройками приложения в amo).
     */
    private function getDriveRedirectUri(): string
    {
        if ($this->driveRedirectUri !== '') {
            return $this->driveRedirectUri;
        }
        return self::REDIRECT_URL;
    }

    /**
     * Перечитать Drive-кредентиалы из БД (нужно, т.к. WorkerAmoHTTP — долгоживущий демон:
     * он кэширует настройки на момент старта; после Save в админке в памяти воркера
     * остаётся старый driveClientId/driveClientSecret, и amo возвращает 401 «Unauthorized»).
     */
    private function reloadDriveCredsFromDb(): void
    {
        try {
            $allSettings = ConnectorDb::invoke('getModuleSettings', [true]);
        } catch (\Throwable $e) {
            return;
        }
        if (! is_array($allSettings) || empty($allSettings['ModuleAmoCrm'])) {
            return;
        }
        $s = (object) $allSettings['ModuleAmoCrm'];
        $this->driveClientId     = trim((string) ($s->driveClientId     ?? ''));
        $this->driveClientSecret = trim((string) ($s->driveClientSecret ?? ''));
        $this->driveRedirectUri  = trim((string) ($s->driveRedirectUri  ?? ''));
        if (isset($s->baseDomain) && trim((string)$s->baseDomain) !== '') {
            $this->baseDomain = (string) $s->baseDomain;
        }
    }

    /**
     * Получение токена Drive из code (отдельная интеграция).
     */
    public function getDriveAccessTokenByCode(string $code): PBXAmoResult
    {
        $result = new PBXAmoResult();
        if (trim($code) === '') {
            $result->messages[] = 'empty code';
            return $result;
        }
        $this->reloadDriveCredsFromDb();
        if ($this->driveClientId === '' || $this->driveClientSecret === '') {
            $result->messages[] = 'driveClientId/driveClientSecret empty';
            return $result;
        }
        $params = [
            'client_id'     => $this->driveClientId,
            'client_secret' => $this->driveClientSecret,
            'grant_type'    => 'authorization_code',
            'code'          => $code,
            'redirect_uri'  => $this->getDriveRedirectUri(),
        ];
        $url         = "https://{$this->baseDomain}/oauth2/access_token";
        $postResult  = ClientHTTP::sendHttpPostFormRequest($url, $params);
        if (! $postResult->success || ! is_array($postResult->data)) {
            return $postResult;
        }
        $json = AuthToken::persistableJsonFromOAuthResponse($postResult->data);
        if ($json === '') {
            $result->messages[] = 'token encode failed';
            return $result;
        }
        $result->success = ConnectorDb::invoke('saveNewSettings', [['driveAuthData' => $json]]);
        if ($result->success) {
            $this->driveToken = new AuthToken($json);
        }
        return $result;
    }

    /**
     * Обновление токена Drive по refresh_token.
     */
    public function refreshDriveToken(): void
    {
        if (! $this->initDone || $this->driveToken === null) {
            return;
        }
        $refreshToken = $this->driveToken->getRefreshToken();
        if ($refreshToken === '') {
            return;
        }
        if (! $this->driveToken->isExpired()) {
            return;
        }
        $this->reloadDriveCredsFromDb();
        if ($this->driveClientId === '' || $this->driveClientSecret === '') {
            return;
        }
        $url    = "https://{$this->baseDomain}/oauth2/access_token";
        $params = [
            'client_id'     => $this->driveClientId,
            'client_secret' => $this->driveClientSecret,
            'grant_type'    => 'refresh_token',
            'refresh_token' => $refreshToken,
            'redirect_uri'  => $this->getDriveRedirectUri(),
        ];
        $result = ClientHTTP::sendHttpPostFormRequest($url, $params);
        if (! $result->success || ! is_array($result->data)) {
            return;
        }
        if (empty($result->data['refresh_token'])) {
            $result->data['refresh_token'] = $refreshToken;
        }
        $json = AuthToken::persistableJsonFromOAuthResponse($result->data);
        if ($json === '') {
            return;
        }
        ConnectorDb::invoke('saveNewSettings', [['driveAuthData' => $json]]);
        $this->driveToken = new AuthToken($json);
    }

    /**
     * Проверка, что OAuth Drive настроен и токен валиден (GET /api/v4/account).
     */
    public function checkDriveConnection(): PBXAmoResult
    {
        $res = new PBXAmoResult();
        if ($this->driveToken === null) {
            $res->messages[] = 'drive_oauth_not_configured';
            return $res;
        }
        $this->refreshDriveToken();
        $access = trim($this->driveToken->getAccessToken());
        if ($access === '') {
            $res->messages[] = 'drive token empty';
            return $res;
        }
        $authorization = $this->driveToken->getTokenType() . ' ' . $access;
        $url           = "https://{$this->baseDomain}/api/v4/account";
        return ClientHTTP::sendHttpGetRequest($url, [], ['Authorization' => $authorization]);
    }

    private function getDriveUploadAuthorizationHeader(): string
    {
        if ($this->driveToken !== null) {
            $this->refreshDriveToken();

            return $this->driveToken->getTokenType() . ' ' . $this->driveToken->getAccessToken();
        }
        $this->refreshToken();

        return $this->token->getTokenType() . ' ' . $this->token->getAccessToken();
    }

    /**
     * Получение токена из code.
     * @param $code
     * @return PBXAmoResult
     */
    public function getAccessTokenByCode($code):PBXAmoResult
    {
        $params  = [
            'client_id'     => $this->getClientId(),
            'client_secret' => $this->getClientSecret(),
            'grant_type'    => 'authorization_code',
            'code'          => $code,
            'redirect_uri'  => self::REDIRECT_URL,
        ];
        $url = "https://$this->baseDomain/oauth2/access_token";
        $result = ClientHTTP::sendHttpPostFormRequest($url, $params);
        if($result->success){
            $result->success = $this->token->saveToken($result->data);
        }
        return $result;
    }

    /**
     * Обновление токена.
     * @return void
     */
    public function refreshToken():void
    {
        if(!$this->initDone){
            return;
        }
        $refreshToken = $this->token->getRefreshToken();
        if(empty($refreshToken)){
            return;
        }
        if(!$this->token->isExpired()){
            // Обновлять токен не требуется.
            return;
        }
        $url = "https://$this->baseDomain/oauth2/access_token";
        $params = [
            'client_id'     => $this->getClientId(),
            'client_secret' => $this->getClientSecret(),
            'grant_type' => 'refresh_token',
            'refresh_token' => $refreshToken,
            'redirect_uri'  => self::REDIRECT_URL,
        ];
        $result = ClientHTTP::sendHttpPostFormRequest($url, $params);
        if($result->success){
            $this->token->saveToken($result->data);
        }
    }

    /**
     * Инициация телефонного звонка.
     *
     * @param $peer_number
     * @param $peer_mobile
     * @param $dest_number
     *
     * @return array
     * @throws \Exception
     */
    public static function amiOriginate($peer_number, $peer_mobile, $dest_number): array
    {
        return Util::getAstManager('off')->Originate(
            'Local/' . $peer_number . '@amo-orig-leg-1',
            null,
            null,
            null,
            "Wait",
            "300",
            null,
            "$dest_number <$dest_number>",
            "_DST_CONTEXT=all_peers,__peer_mobile={$peer_mobile}",
        );
    }

    /**
     * Получение данных аккаунта.
     */
    public function checkConnection(bool $updatePortalId = false): PBXAmoResult
    {
        if(!PbxExtensionUtils::isEnabled($this->moduleUniqueId)){
            return new PBXAmoResult();
        }
        $authorization = $this->token->getTokenType().' '.$this->token->getAccessToken();
        if(empty(trim($authorization))){
            return new PBXAmoResult();
        }
        $url = "https://$this->baseDomain/api/v4/account";
        $headers = [
            'Authorization' => $authorization,
        ];

        $connectionData = ClientHTTP::sendHttpGetRequest($url, [], $headers);
        $id = (int)($connectionData->data['id']??0);
        if($updatePortalId && $id > 0){
            $this->token->savePortalId($id);
        }
        return $connectionData;
    }

    public function addCalls($calls, $entity_type):PBXApiResult
    {
        $url = "https://$this->baseDomain/api/v4/$entity_type/notes";
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        return ClientHTTP::sendHttpPostRequest($url, $calls, $headers);
    }

    /**
     * URL облачного диска amo (из account?with=drive_url). Кэшируется на экземпляр.
     */
    private function getAmoDriveBaseUrl(): string
    {
        if ($this->cachedDriveUrl !== null) {
            return $this->cachedDriveUrl;
        }
        $this->refreshToken();
        $authorization = $this->token->getTokenType() . ' ' . $this->token->getAccessToken();
        $url = "https://{$this->baseDomain}/api/v4/account?with=drive_url";
        $res = ClientHTTP::sendHttpGetRequest($url, [], ['Authorization' => $authorization]);
        if (! $res->success || ! is_array($res->data)) {
            $this->cachedDriveUrl = '';
            return '';
        }
        $drive = $res->data['drive_url'] ?? ($res->data['_embedded']['drive_url'] ?? '');
        $this->cachedDriveUrl = is_string($drive) ? rtrim($drive, '/') : '';
        return $this->cachedDriveUrl;
    }

    /**
     * Загрузка файла записи в облако amo (Drive) и получение публичного download.href
     * (логика как в Callspire: AmoCrmService.UploadFileAsync + GetFileDownloadLinkAsync).
     * Ссылка на Miko /pbxcore/api/amo-crm/playback в примечании «звонок» в amo не подходит,
     * если Miko не доступен извне или нет маршрута — amo валидирует URL и плеер качает с Drive.
     *
     * @return PBXAmoResult success + data = string (URL) при успехе
     */
    public function uploadRecordingToAmoDriveAndGetLink(string $absolutePath): PBXAmoResult
    {
        $out = new PBXAmoResult();
        if ($absolutePath === '' || ! is_file($absolutePath) || ! is_readable($absolutePath)) {
            $out->messages[] = 'Recording file not found';
            return $out;
        }
        $size = filesize($absolutePath);
        if ($size === false || $size < 1) {
            $out->messages[] = 'Recording file empty';
            return $out;
        }

        $driveBase = $this->getAmoDriveBaseUrl();
        if ($driveBase === '') {
            $out->messages[] = 'drive_url unavailable (GET /api/v4/account?with=drive_url)';
            return $out;
        }

        $this->refreshToken();
        $this->refreshDriveToken();
        $authHeader = $this->getDriveUploadAuthorizationHeader();

        $ext = strtolower((string)pathinfo($absolutePath, PATHINFO_EXTENSION));
        if ($ext === 'mp3') {
            $contentType = 'audio/mpeg';
        } elseif ($ext === 'wav') {
            $contentType = 'audio/wav';
        } elseif ($ext === 'webm') {
            $contentType = 'audio/webm';
        } elseif ($ext === 'm4a') {
            $contentType = 'audio/mp4';
        } else {
            $contentType = 'application/octet-stream';
        }

        $client = new Client([
            'timeout'         => 300,
            'connect_timeout' => 30,
            'http_errors'     => false,
        ]);

        $sessionUrl = $driveBase . '/v1.0/sessions';
        try {
            $sessionBody = json_encode([
                'file_name'    => basename($absolutePath),
                'file_size'    => $size,
                'content_type' => $contentType,
            ], JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            $out->messages[] = $e->getMessage();
            return $out;
        }

        $sr = $client->post($sessionUrl, [
            'headers' => [
                'Authorization' => $authHeader,
                'Content-Type'   => 'application/json',
            ],
            'body'    => $sessionBody,
        ]);
        $sc = $sr->getStatusCode();
        $sessionJson = (string) $sr->getBody();
        if ($sc < 200 || $sc >= 300) {
            $out->messages[] = "Drive session HTTP $sc: " . $sessionJson;
            return $out;
        }
        try {
            $sessionData = json_decode($sessionJson, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            $out->messages[] = 'Session JSON: ' . $e->getMessage();
            return $out;
        }
        $uploadUrl = (string) ($sessionData['upload_url'] ?? '');
        $maxPart   = (int) ($sessionData['max_part_size'] ?? 524288);
        if ($maxPart < 1) {
            $maxPart = 524288;
        }
        if ($uploadUrl === '') {
            $out->messages[] = 'No upload_url in session';
            return $out;
        }

        $fh = fopen($absolutePath, 'rb');
        if ($fh === false) {
            $out->messages[] = 'Cannot open file';
            return $out;
        }
        $totalRead = 0;
        $fileUuid  = '';
        try {
            while ($totalRead < $size) {
                $remaining = $size - $totalRead;
                $chunkSize = (int) min($maxPart, $remaining);
                $chunk     = fread($fh, $chunkSize);
                if ($chunk === false || $chunk === '') {
                    break;
                }
                $pr   = $client->post($uploadUrl, [
                    'headers' => [
                        'Authorization'  => $authHeader,
                        'Content-Type'   => 'application/octet-stream',
                        'Content-Length' => (string) strlen($chunk),
                    ],
                    'body'    => $chunk,
                ]);
                $pc   = $pr->getStatusCode();
                $pbody = (string) $pr->getBody();
                if ($pc < 200 || $pc >= 300) {
                    $out->messages[] = "Part upload HTTP $pc: " . $pbody;
                    return $out;
                }
                $totalRead += strlen($chunk);
                try {
                    $pdata = json_decode($pbody, true, 512, JSON_THROW_ON_ERROR);
                } catch (JsonException $e) {
                    $out->messages[] = 'Part JSON: ' . $e->getMessage();
                    return $out;
                }
                if ($totalRead < $size) {
                    $uploadUrl = (string) ($pdata['next_url'] ?? '');
                    if ($uploadUrl === '') {
                        $out->messages[] = 'next_url missing in part response';
                        return $out;
                    }
                } else {
                    $fileUuid = (string) ($pdata['uuid'] ?? $pdata['file_uuid'] ?? '');
                }
            }
        } finally {
            fclose($fh);
        }
        if ($fileUuid === '') {
            $out->messages[] = 'No file UUID after upload';
            return $out;
        }

        $infoUrl = $driveBase . '/v1.0/files/' . rawurlencode($fileUuid);
        $ir      = $client->get($infoUrl, [
            'headers' => ['Authorization' => $authHeader],
        ]);
        $ic     = $ir->getStatusCode();
        $ibody  = (string) $ir->getBody();
        if ($ic < 200 || $ic >= 300) {
            $out->messages[] = "File info HTTP $ic: " . $ibody;
            return $out;
        }
        try {
            $info = json_decode($ibody, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            $out->messages[] = 'File info JSON: ' . $e->getMessage();
            return $out;
        }
        $href = $info['_links']['download']['href'] ?? $info['download']['href'] ?? $info['href'] ?? '';
        if (! is_string($href) || $href === '') {
            $out->messages[] = 'No download href in file info';
            if (is_array($info)) {
                $out->data = $info;
            }
            return $out;
        }
        $out->success = true;
        $out->data    = $href;
        return $out;
    }

    /**
     * Синхронизация воронок.
     * @param $portalId
     * @return array
     */
    public function syncPipeLines($portalId):array
    {
        $url = "https://$this->baseDomain/api/v4/leads/pipelines";
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        $response = ClientHTTP::sendHttpGetRequest($url, [], $headers);
        if($response->success){
            $data = $response->data['_embedded']['pipelines']??[];
            $pipeLines = ConnectorDb::invoke('updatePipelines', [$data]);
        }else{
            $pipeLines = ConnectorDb::invoke('getPipeLines', []);
        }
        return $pipeLines;
    }

    /**
     * Запрос в amoCRM сведений о контакте.
     * @param $phone
     * @return PBXApiResult
     */
    public function getContactDataByPhone($phone):PBXApiResult
    {
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        $result   = new PBXApiResult();
        $digits   = preg_replace('/\D+/', '', (string)$phone);
        if(strlen($digits) < 5){
            return $result;
        }
        $indexWanted = self::getPhoneIndex($phone);

        $url = "https://$this->baseDomain/private/api/v2/json/contacts/list";
        $params = [
            'query' => $phone
        ];
        $response = ClientHTTP::sendHttpGetRequest($url, $params, $headers);
        $contact = $response->data['response']['contacts'][0]??false;
        if($response->success && $contact){
            $result->data = [
                'id'     => $contact['id']??'',
                'name'   => $contact['name']??'',
                'company'=> $contact['company_name']??'',
                'userId' => $contact['responsible_user_id']??'',
                'number' => $phone,
                'entity' => 'contact'

            ];
            $result->success = !empty($result->data['id']);
            if($result->success){
                return $result;
            }
        }
        // v2 private API часто пустой для интеграций на OAuth — догружаем через v4
        $url4 = "https://$this->baseDomain/api/v4/contacts";
        $res4 = ClientHTTP::sendHttpGetRequest($url4, [
            'query' => $digits,
            'limit' => 25,
        ], $headers);
        if(!$res4->success){
            return $result;
        }
        $list = $res4->data['_embedded']['contacts']??[];
        foreach($list as $c){
            if($this->contactV4RowMatchesPhone($c, (string)$indexWanted, $digits)){
                $result->data = [
                    'id'     => $c['id']??'',
                    'name'   => $c['name']??'',
                    'company'=> $c['company_name']??'',
                    'userId' => $c['responsible_user_id']??'',
                    'number' => $phone,
                    'entity' => 'contact'
                ];
                $result->success = !empty($result->data['id']);
                if($result->success){
                    return $result;
                }
            }
        }
        return $result;
    }

    /**
     * Сверяет контакт v4 с искомым номером (поле PHONE в amo), чтобы query не дал «чужой» контакт.
     * @param array  $contact
     * @param string $indexWanted последние 10 цифр, как getPhoneIndex
     * @param string $digits полностью цифры исходного поиска
     */
    private function contactV4RowMatchesPhone(array $contact, string $indexWanted, string $digits): bool
    {
        foreach($contact['custom_fields_values'] ?? [] as $field){
            if(($field['field_code'] ?? '') !== 'PHONE'){
                continue;
            }
            foreach($field['values'] ?? [] as $value){
                $raw = (string)($value['value'] ?? '');
                if($raw === ''){
                    continue;
                }
                $vDigits = preg_replace('/\D+/', '', $raw);
                if($vDigits === $digits || self::getPhoneIndex($raw) === $indexWanted){
                    return true;
                }
            }
        }
        return false;
    }

    public function addUnsorted($calls):PBXApiResult
    {
        $url = "https://$this->baseDomain/api/v4/leads/unsorted/sip";
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        return ClientHTTP::sendHttpPostRequest($url, $calls, $headers);
    }

    /**
     * Пакетное добавление сделок.
     * @param $calls
     * @return PBXApiResult
     */
    public function addLeads($calls):PBXApiResult
    {
        $url = "https://$this->baseDomain/api/v4/leads";
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        return ClientHTTP::sendHttpPostRequest($url, $calls, $headers);
    }

    /**
     * Пакетное добавление сделок.
     * @param $calls
     * @return PBXApiResult
     */
    public function addTasks($calls):PBXApiResult
    {
        $url = "https://$this->baseDomain/api/v4/tasks";
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        return ClientHTTP::sendHttpPostRequest($url, $calls, $headers);
    }

    /**
     * Получает изменненные контакты / компании.
     * @param string $type
     * @param string $pageLink
     * @return PBXApiResult
     */
    public function getChangedEntity(string $pageLink, string $type):PBXApiResult
    {
        $types = [
            self::ENTITY_COMPANIES  => 'company',
            self::ENTITY_CONTACTS   => 'contact',
            self::ENTITY_LEADS      => self::ENTITY_LEADS,
        ];
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        $url = str_replace(self::EMPTY_HOST_VALUE, $this->baseDomain ,$pageLink);
        $params = [];
        $response = ClientHTTP::sendHttpGetRequest($url, $params, $headers);
        $result   = new PBXApiResult();
        $nextUrl = $response->data['_links']['next']['href']??'';
        $result->data = [
            $type => [],
            'nextPage' => $nextUrl,
        ];
        foreach ($response->data['_embedded'][$type]??[] as $contact){
            $contact['type'] = $types[$type];
            $result->data[$type][]  = $contact;
        }
        return $result;
    }

    /**
     * Создание контактов в amoCRM
     * @param array $data
     * @return PBXApiResult
     */
    public function createContacts(array $data):PBXApiResult
    {
        $url = "https://$this->baseDomain/api/v4/contacts";
        $headers = [
            'Authorization' => $this->token->getTokenType().' '.$this->token->getAccessToken(),
        ];
        $params = [];
        foreach ($data as $contactData){
            $phone = $contactData['phone']??'';
            if(empty($phone)){
                continue;
            }
            $params[$contactData['phone']] = [
                'name' => $contactData['contactName']??'-- '.$contactData['phone'].' --',
                'custom_fields_values' => [
                    [
                        'field_code' => 'PHONE',
                        'values' => [['value' => $contactData['phone']]]
                    ]
                ]
            ];
            if(isset($contactData['request_id'])){
                $params[$contactData['phone']]['request_id'] = $contactData['request_id'];
            }
            if(isset($contactData['responsible_user_id'])) {
                $params[$contactData['phone']]['responsible_user_id'] = $contactData['responsible_user_id'];
            }
        }
        if(empty($params)){
            $result = new PBXAmoResult();
            $result->success = true;
        }else{
            $params = array_values($params);
            $result = ClientHTTP::sendHttpPostRequest($url, $params, $headers);
        }
        return $result;
    }

    /**
     * Обновление таблицы пользователей AMO.
     */
    public static function updateUsers():array
    {
        $users = [];
        $amoUsers = ConnectorDb::invoke('getPortalUsers', [1]);
        foreach ($amoUsers as $user){
            if(!is_numeric($user['amoUserId'])){
                continue;
            }
            $users[$user['number']] = (int)$user['amoUserId'];
        }
        $extensionLength = (int)PbxSettings::getValueByKey('PBXInternalExtensionLength');
        $userList   = [];
        $innerNums = [];
        /** @var Extensions $ext */
        $extensions = Extensions::find(['order' => 'type DESC']);
        foreach ($extensions as $ext){
            if($ext->type === Extensions::TYPE_SIP){
                $userList[$ext->userid] = $ext->number;
            }elseif($ext->type === Extensions::TYPE_EXTERNAL && isset($userList[$ext->userid])){
                $innerNum = $userList[$ext->userid];
                if(isset($users[$innerNum])){
                    $amoUserId = $users[$innerNum];
                    $users[self::getPhoneIndex($ext->number)] = (int)$amoUserId;
                }
            }
            $innerNums[] = self::getPhoneIndex($ext->number);
        }
        unset($userList);
        return [$extensionLength, $users, $innerNums];
    }

    /**
     * Возвращает усеценный слева номер телефона.
     *
     * @param $number
     *
     * @return bool|string
     */
    public static function getPhoneIndex($number)
    {
        $number = preg_replace('/\D+/', '', $number);
        if(!is_numeric(str_replace('+', '', $number))){
            return $number;
        }
        return substr($number, -10);
    }

}