<?php

namespace Modules\ModuleAmoCrm\Lib;

use MikoPBX\Modules\PbxExtensionBase;

class AmoCrmMainBase extends PbxExtensionBase
{
    public const   REDIRECT_URL  = 'https://www.mikopbx.com/ajax/helpers/amocrm/index.php';
    public const   CLIENT_SECRET = 'OCEGwykePGwXuvSPMIbWrWAS0KXyhPLo1sA7nMnKOrDzm9bf1BcaUB02gfeCvkyP';
    public const   CLIENT_ID     = '13cdac22-f248-4175-a282-fbfc8d45dd03';
}