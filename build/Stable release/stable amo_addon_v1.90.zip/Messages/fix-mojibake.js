/**
 * Fix double-encoded UTF-8 in ru.php (UTF-8 misread as Latin-1 then saved as UTF-8).
 * Usage: node fix-mojibake.js
 */
const fs = require('fs');
const path = require('path');
const dir = __dirname;
const files = fs.readdirSync(dir).filter((f) => f.endsWith('.php') && f !== 'fix-mojibake.js');

function fixString(s) {
  try {
    return Buffer.from(s, 'latin1').toString('utf8');
  } catch {
    return s;
  }
}

function fixFile(filePath) {
  let raw = fs.readFileSync(filePath, 'utf8');
  const orig = raw;

  // Only fix lines that look like mojibake (Cyrillic-looking Latin letters)
  if (!raw.includes('Р') && !raw.includes('С')) {
    return false;
  }

  // Replace => '...' and => "..." string values on return array lines
  raw = raw.replace(/(=>\s*)'((?:\\'|[^'])*)'/g, (m, pre, inner) => {
    const fixed = fixString(inner);
    return pre + "'" + fixed.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";
  });

  if (raw === orig) return false;
  fs.writeFileSync(filePath, raw, 'utf8');
  return true;
}

for (const f of files) {
  const fp = path.join(dir, f);
  if (fixFile(fp)) console.log('fixed', f);
}
