# Reverses UTF-8 bytes misinterpreted as Windows-1251 (mojibake in ru.php etc.)
param(
    [string]$Path = (Join-Path $PSScriptRoot 'ru.php')
)
$cp1251 = [System.Text.Encoding]::GetEncoding(1251)
$utf8 = [System.Text.Encoding]::UTF8
$s = [System.IO.File]::ReadAllText($Path, [System.Text.UTF8Encoding]::new($false))
$bytes = New-Object byte[] $s.Length
for ($i = 0; $i -lt $s.Length; $i++) {
    $ch = $s[$i]
    $one = $cp1251.GetBytes([string]$ch)
    if ($one.Length -lt 1) { throw "No byte for char at $i" }
    $bytes[$i] = $one[0]
}
$fixed = $utf8.GetString($bytes)
[System.IO.File]::WriteAllText($Path, $fixed, [System.Text.UTF8Encoding]::new($false))
Write-Host "Fixed: $Path"
