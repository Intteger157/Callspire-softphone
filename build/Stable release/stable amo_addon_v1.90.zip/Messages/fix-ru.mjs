import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const fp = path.join(__dirname, 'ru.php');
const s = fs.readFileSync(fp, 'utf8');
// UTF-8 bytes misinterpreted as Latin-1 / ISO-8859-1 then re-encoded as UTF-8
const fixed = Buffer.from(s, 'latin1').toString('utf8');
fs.writeFileSync(fp, fixed, 'utf8');
console.log('ok', fp);
