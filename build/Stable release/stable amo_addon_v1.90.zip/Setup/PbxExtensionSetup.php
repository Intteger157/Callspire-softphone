<?php
/*
 * MikoPBX - free phone system for small business
 * Copyright © 2017-2023 Alexey Portnov and Nikolay Beketov
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program.
 * If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * Copyright © MIKO LLC - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Alexey Portnov, 5 2019
 */

namespace Modules\ModuleAmoCrm\Setup;

use MikoPBX\Common\Models\PbxSettings;
use MikoPBX\Common\Providers\ModulesDBConnectionsProvider;
use MikoPBX\Core\System\Util;
use MikoPBX\Modules\Setup\PbxExtensionSetupBase;
use Modules\ModuleAmoCrm\Models\ModuleAmoCrm;


/**
 * Class PbxExtensionSetup
 * Module installer and uninstaller
 *
 * @package Modules\ModuleAmoCrm\Setup
 */
class PbxExtensionSetup extends PbxExtensionSetupBase
{
    public function installModule(): bool
    {
        ModulesDBConnectionsProvider::recreateModulesDBConnections();
        $ok = parent::installModule();
        $this->ensureDisableOutgoingRecordingLinkColumn();
        $this->ensureDriveOAuthColumns();
        if ($ok) {
            $this->initCdrReferenceDateIfEmpty();
        }
        return $ok;
    }

    /**
     * При первой установке модуля задать referenceDate = «сейчас», чтобы AmoCdrDaemon не подтягивал старую CDR.
     */
    private function initCdrReferenceDateIfEmpty(): void
    {
        try {
            ModulesDBConnectionsProvider::recreateModulesDBConnections();
            $rec = ModuleAmoCrm::findFirst();
            if ($rec === null) {
                return;
            }
            $rd = trim((string)($rec->referenceDate ?? ''));
            $ts = $rd === '' ? false : strtotime($rd);
            $badSmallId = $rd !== '' && strlen($rd) <= 2 && ctype_digit($rd);
            if ($rd === '' || $ts === false || $ts < strtotime('2010-01-01') || $badSmallId) {
                $rec->referenceDate = Util::getNowDate();
                $rec->save();
            }
        } catch (\Throwable $e) {
            // не блокируем установку модуля
        }
    }

    /**
     * Добавление колонки при обновлении модуля с версии без этого поля.
     */
    private function ensureDisableOutgoingRecordingLinkColumn(): void
    {
        try {
            $db = ModuleAmoCrm::getReadConnection();
            $db->execute('ALTER TABLE m_ModuleAmoCrm ADD COLUMN disableOutgoingRecordingLink INTEGER DEFAULT 0');
        } catch (\Throwable $e) {
            // колонка уже есть
        }
    }

    /**
     * Отдельная OAuth-интеграция для загрузки записей в amo Drive (внешнее приложение в маркетплейсе).
     */
    private function ensureDriveOAuthColumns(): void
    {
        self::migrateDriveOAuthColumns();
    }

    /**
     * Добавляет колонки Drive-OAuth при обновлении модуля / первом включении.
     */
    public static function migrateDriveOAuthColumns(): void
    {
        try {
            ModulesDBConnectionsProvider::recreateModulesDBConnections();
        } catch (\Throwable $e) {
            // ignore
        }
        try {
            $db = ModuleAmoCrm::getReadConnection();
        } catch (\Throwable $e) {
            return;
        }
        foreach ([
            'driveAuthData' => 'ALTER TABLE m_ModuleAmoCrm ADD COLUMN driveAuthData TEXT',
            'driveClientId' => 'ALTER TABLE m_ModuleAmoCrm ADD COLUMN driveClientId TEXT',
            'driveClientSecret' => 'ALTER TABLE m_ModuleAmoCrm ADD COLUMN driveClientSecret TEXT',
            'driveRedirectUri' => 'ALTER TABLE m_ModuleAmoCrm ADD COLUMN driveRedirectUri TEXT',
            'recordingPublicBaseUrl' => 'ALTER TABLE m_ModuleAmoCrm ADD COLUMN recordingPublicBaseUrl TEXT',
        ] as $col => $sql) {
            try {
                $db->execute($sql);
            } catch (\Throwable $e) {
                // колонка уже есть
            }
        }
    }

    /**
     * Adds the module to the sidebar menu.
     *
     * @return bool The result of the addition process.
     */
    public function addToSidebar(): bool
    {
        $menuSettingsKey           = "AdditionalMenuItem{$this->moduleUniqueID}";
        $menuSettings              = PbxSettings::findFirstByKey($menuSettingsKey);
        if ($menuSettings === null) {
            $menuSettings      = new PbxSettings();
            $menuSettings->key = $menuSettingsKey;
        }
        $value               = [
            'uniqid'        => $this->moduleUniqueID,
            'group'         => 'integrations',
            'iconClass'     => 'handshake outline',
            'caption'       => "Breadcrumb{$this->moduleUniqueID}",
            'showAtSidebar' => true,
        ];
        $menuSettings->value = json_encode($value);

        return $menuSettings->save();
    }

}